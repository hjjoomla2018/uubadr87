ALTER TABLE "#__fields_groups" ADD COLUMN "params" TEXT NOT NULL;
